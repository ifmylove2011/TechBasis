package com.xter.okhttp.model;

/**
 * msgType为9
 */
public class OfflineDeviceObject {

	public String deviceId;
	public Integer deviceType;
	public String deviceDesc;
	public String imei;
	public String mac;
	public String positionDesc;
	public Integer lastCheckTime;
}
